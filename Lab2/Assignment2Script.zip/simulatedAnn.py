from __future__ import print_function
import os
import math
import random
from simanneal import Annealer

class DSEOptimization(Annealer):

	"""Test annealer with a travelling salesman problem.
	"""

	def __init__(self, state):
		super(DSEOptimization, self).__init__(state)  # important!

	def move(self):
		"""Change all config parameters"""
		IWRange=[2,4,8]
		IW = random.choice(IWRange)
		Mpy = random.randint(1, IW)
		command = "./result.sh"+" "+str(IW)+" "+str(Mpy) 
		os.system(command)
		#os.system("./result.sh 4 4 2 1 64 8")	
		self.state[0] = IW
		self.state[1] = Mpy

	def energy(self):
		"""This is my objective function: Need to minimize this"""
		e = 0
		text_file = open("evaluation", "r")
		lines = text_file.read().split('\n')
		appPerf = float(lines[0])
		totalArea= float(lines[1])
		#print appPerf
		#print totalArea
		text_file.close()
		e = appPerf*totalArea
		return e



if __name__ == '__main__':

	# initial state, state of reference arch
	init_state = [2, 2]
	os.system("./result.sh 2 2")
	
	tsp = DSEOptimization(init_state)
	tsp.steps = 50
	
	# since our state is just a list, slice is the fastest way to copy
	tsp.copy_strategy = "slice"
	
	tsp.Tmax = 49.0
	state, e = tsp.anneal()

	print()
	print("This is the final energy: %i" % e)
	for parameter in state:
		print("\t", parameter)
