#NEW CONFIG
NEWIssueWidth=$1
NEWAlu=$1
NEWMpy=$2

NEWIssueWidthGLOBAL=$1

config="configuration.mm"

#Reference Performance
conv_ref=1
matrix_ref=1
greyscale_ref=1
jpeg_ref=1

#Reference Area
refAreaALU=3273
refAreaMpy=40614

refAreaLWSW=1500
refAreaGR=26388
refAreaBR=258
refAreaCache=1000 
refTotalArea=72033

#BOOKKEEPING
STRINGIssueWidthGLOBAL='RES: IssueWidth     '
STRINGIssueWidth='RES: IssueWidth.0   '
STRINGAlu='RES: Alu.0          '
STRINGMpy='RES: Mpy.0          '

#UPDATED CONFIG
UPDATEDIssueWidthGLOBAL="$STRINGIssueWidthGLOBAL$NEWIssueWidthGLOBAL"
UPDATEDIssueWidth="$STRINGIssueWidth$NEWIssueWidth"
UPDATEDAlu="$STRINGAlu$NEWAlu"
UPDATEDMpy="$STRINGMpy$NEWMpy"

#CONFIG PARAMETERS IN FILE
IssueWidthGLOBAL=$(sed '16q;d' $config)
IssueWidth=$(sed '17q;d' $config)
Alu=$(sed '18q;d' $config)
Mpy=$(sed '22q;d' $config)

#Change value of configuration file
#global
sed -i -e "s/$IssueWidthGLOBAL/$UPDATEDIssueWidthGLOBAL/g" $config
sed -i -e "s/$IssueWidth/$UPDATEDIssueWidth/g" $config
sed -i -e "s/$Alu/$UPDATEDAlu/g" $config
sed -i -e "s/$Mpy/$UPDATEDMpy/g" $config

#Area Calculations
AreaGR=$(((refAreaGR/64)*63*(NEWIssueWidth/4)*(NEWIssueWidth/4)))
AreaBR=$(((refAreaBR/8)*8*(NEWIssueWidth/4)*(NEWIssueWidth/4)))
AreaCache=$(((1+1+0)*refAreaCache))
TotalArea=$(((NEWAlu*refAreaALU)+(NEWMpy*refAreaMpy)+(1*refAreaLWSW)+(AreaGR)+(AreaBR)+(AreaCache)))

/home/user/workspace/tools/bin/run convolution_7x7 -O3
/home/user/workspace/tools/bin/run matrix -O3
/home/user/workspace/tools/bin/run greyscale -O3
/home/user/workspace/tools/bin/run jpeg -O3


log1="./output-convolution_7x7.c/ta.log.000"
log2="./output-matrix.c/ta.log.000"
log3="./output-greyscale.c/ta.log.000"
log4="./output-jpeg.c/ta.log.000"

#Extract 2nd line from logfile
rawPerf1=$(sed '2q;d'  $log1)
rawPerf2=$(sed '2q;d'  $log2)
rawPerf3=$(sed '2q;d'  $log3)
rawPerf4=$(sed '2q;d'  $log4)

#Extract number of execution cycles
Perf1=$(sed 's/^[^0-9]*\([0-9]\+\).*$/\1/' <<< "$rawPerf1")
Perf2=$(sed 's/^[^0-9]*\([0-9]\+\).*$/\1/' <<< "$rawPerf2")
Perf3=$(sed 's/^[^0-9]*\([0-9]\+\).*$/\1/' <<< "$rawPerf3")
Perf4=$(sed 's/^[^0-9]*\([0-9]\+\).*$/\1/' <<< "$rawPerf4")

NormPerf1=$(bc <<< "scale = 10; $Perf1/$conv_ref")
NormPerf2=$(bc <<< "scale = 10; $Perf2/$matrix_ref")
NormPerf3=$(bc <<< "scale = 10; $Perf3/$greyscale_ref")
NormPerf4=$(bc <<< "scale = 10; $Perf4/$jpeg_ref")

#Change this according to which combo you want
AppPerf=$(bc <<< "scale = 10; sqrt($NormPerf1*$NormPerf2)")

#echo $AppPerf
echo "$AppPerf" > evaluation
echo "$TotalArea" >> evaluation

echo "Performance: $AppPerf" >> datapoints
echo "Area: $TotalArea" >> datapoints
echo "IW : $NEWIssueWidth" >> datapoints
echo "Multipliers : $NEWMpy" >> datapoints
